-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 23, 2020 at 04:05 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gudang`
--

-- --------------------------------------------------------

--
-- Table structure for table `persediaanbarang`
--

CREATE TABLE `persediaanbarang` (
  `id_barang` int(11) NOT NULL,
  `kodebarang` varchar(5) NOT NULL,
  `namabarang` varchar(55) NOT NULL,
  `hargapokok` char(6) NOT NULL,
  `hargajualsatuan` char(6) NOT NULL,
  `jumlah` char(4) NOT NULL,
  `nilai` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `persediaanbarang`
--

INSERT INTO `persediaanbarang` (`id_barang`, `kodebarang`, `namabarang`, `hargapokok`, `hargajualsatuan`, `jumlah`, `nilai`) VALUES
(1, 'A01', 'Aqua Botol', '3000', '3500', '100', '350000'),
(3, 'A02', 'Stella Home Air Freshener Apple Fiesta', '27000', '29000', '50', '1450000'),
(5, 'A03', 'Kursi Mainan', '45000', '40000', '50', '2000000'),
(6, 'A04', 'Sosro Fruit Tea Apel', '3200', '5000', '100', '500000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `persediaanbarang`
--
ALTER TABLE `persediaanbarang`
  ADD PRIMARY KEY (`id_barang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `persediaanbarang`
--
ALTER TABLE `persediaanbarang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
