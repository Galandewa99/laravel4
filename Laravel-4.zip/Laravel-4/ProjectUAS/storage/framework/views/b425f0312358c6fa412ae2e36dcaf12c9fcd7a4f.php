<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pengolahan Data Gudang Barang</title>
</head>
<body>
 
	<h3>Data Persediaan</h3>
 
	<a href="/persediaanbarang/tambah"> + Tambah Persediaan Baru</a>
	
	<br/>
	<br/>
 
	<table border="1">
		<tr>
			<th>Kode Barang</th>
			<th>Nama Barang</th>
			<th>Harga Pokok</th>
			<th>Harga Jual Persatuan</th>
			<th>Jumlah</th>
            <th>Nilai</th>
            <th>Aksi</th>
		</tr>
		<?php $__currentLoopData = $persediaanbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->kodebarang); ?></td>
			<td><?php echo e($p->namabarang); ?></td>
			<td><?php echo e($p->hargapokok); ?></td>
            <td><?php echo e($p->hargajualsatuan); ?></td>
            <td><?php echo e($p->jumlah); ?></td>
			<td><?php echo e($p->nilai); ?></td>
			<td>
				<a href="/persediaanbarang/edit/<?php echo e($p->id_barang); ?>">Edit</a>
				|
				<a href="/persediaanbarang/hapus/<?php echo e($p->id_barang); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
 
 
</body>
</html><?php /**PATH /opt/lampp/htdocs/ProjectUAS/resources/views/index.blade.php ENDPATH**/ ?>