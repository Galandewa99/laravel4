<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pengolahan Data Gudang Barang</title>
</head>
<body>
 
	<h3>Data Persediaan</h3>
 
	<a href="/persediaanbarang"> Kembali</a>
	
	<br/>
	<br/>
 
	<form action="/persediaanbarang/store" method="post">
		<?php echo e(csrf_field()); ?>

		Kode Barang <input type="text" name="kodebarang" required="required"> <br/>
		Nama Barang <input type="text" name="namabarang" required="required"> <br/>
		Harga Pokok <input type="number" name="hargapokok" required="required"> <br/>
		Harga Jual Satuan <input type="number" name="hargajualsatuan" required="required"> <br/>
        Jumlah <input type="number" name="jumlah" required="required"> <br/>
        Nilai <input type="number" name="nilai" required="required"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
 
</body>
</html><?php /**PATH /opt/lampp/htdocs/ProjectUAS/resources/views/tambah.blade.php ENDPATH**/ ?>