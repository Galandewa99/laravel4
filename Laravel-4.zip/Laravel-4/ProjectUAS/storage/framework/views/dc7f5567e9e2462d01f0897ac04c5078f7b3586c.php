<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pengolahan Data Gudang Barang</title>
</head>
<body>
 
	<h3>Edit Pegawai</h3>
 
	<a href="/persediaanbarang"> Kembali</a>
	
	<br/>
	<br/>
 
	<?php $__currentLoopData = $persediaanbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="/persediaanbarang/update" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="id_barang" value="<?php echo e($p->id_barang); ?>"> <br/>
		Kode Barang <input type="text" required="required" name="kodebarang" value="<?php echo e($p->kodebarang); ?>"> <br/>
		Nama Barang <input type="text" required="required" name="namabarang" value="<?php echo e($p->namabarang); ?>"> <br/>
		Harga Pokok <input type="number" required="required" name="hargapokok" value="<?php echo e($p->hargapokok); ?>"> <br/>
		Harga Jual Satuan <input type="number" required="required" name="hargajualsatuan" value="<?php echo e($p->hargajualsatuan); ?>"> <br/>
        Jumlah <input type="number" required="required" name="jumlah" value="<?php echo e($p->jumlah); ?>"> <br/>
        Nilai <input type="number" required="required" name="nilai" value="<?php echo e($p->nilai); ?>"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
 
</body>
</html><?php /**PATH /opt/lampp/htdocs/ProjectUAS/resources/views/edit.blade.php ENDPATH**/ ?>