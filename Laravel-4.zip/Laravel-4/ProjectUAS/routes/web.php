<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//route CRUD
Route::get('/persediaanbarang','PersediaanBarangController@index');
Route::get('/persediaanbarang/tambah','PersediaanBarangController@tambah');
Route::post('/persediaanbarang/store','PersediaanBarangController@store');
Route::get('/persediaanbarang/edit/{id}','PersediaanBarangController@edit');
Route::post('/persediaanbarang/update','PersediaanBarangController@update');
Route::get('/persediaanbarang/hapus/{id}','PersediaanBarangController@hapus');